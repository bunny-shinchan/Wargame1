package com.jesseboyd.warGame;

public interface Card {

	int getValue();

}